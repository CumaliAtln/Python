import tkinter

class GeeksBro:

    def __init__(self, window):
         # create a button to call a function called 'say_hi'
        self.text_btn = tkinter.Button(window, text = "Click Me!", command = self.say_hi)
        self.text_btn.pack()
        # closing the 'window' when you click the button
        self.close_btn = tkinter.Button(window, text = "Close", command = window.quit)
        self.close_btn.pack()

    def say_hi(self):
        tkinter.Label(window, text = "Hi").pack()

window = tkinter.Tk()
window.title("GUI")

geeks_bro = GeeksBro(window)

window.mainloop()
